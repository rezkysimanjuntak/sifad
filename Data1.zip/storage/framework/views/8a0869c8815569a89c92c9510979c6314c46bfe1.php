<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Siswa</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Data Siswa <a href="<?php echo e(URL::to('siswa/tambah')); ?>" class="btn btn-success btn-flat btn-sm" data-toggle="modal" title="Tambah"><i class="fa fa-plus"></i></a></h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="dataKurikulum" class="table table-bordered table-hover">
                    <thead>
                      <tr>                        
                        <th>NISN</th>
                        <th>NIS</th>                    
                        <th>Nama</th>                            
                        <th>Kelas</th>                        
                        <th>Angkatan</th>
                        <th>Status Aktif</th> 
                        <th>Aksi</th> 
                      </tr>
                    </thead>
                    <tbody>
                     <?php foreach ($siswa as $itemSiswa):  ?>
                      <tr>
                        <td><?php echo e($itemSiswa->sisNisn); ?></td>
                        <td><?php echo e($itemSiswa->sisNis); ?></td>
                        <td><?php echo e($itemSiswa->sisNama); ?></td>
                        <td><?php echo e($itemSiswa->sisKelasKode); ?></td> 
                        <td><?php echo e($itemSiswa->sisAngkatan); ?></td> 
                        <td><?php echo e($itemSiswa->sisStatusAktif); ?></td>
                        <td><a href="<?php echo e(URL::to('siswa/'.$itemSiswa->sisNisn.'/detail')); ?>">
                              <span class="label label-info"><i class="fa fa-list"> Detail </i></span>
                              </a>
                        </td>
                      </tr>
                      <?php endforeach  ?> 
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>NISN</th>
                        <th>NIS</th>                    
                        <th>Nama</th>                            
                        <th>Kelas</th>                        
                        <th>Status Aktif</th> 
                        <th>Aksi</th> 
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

            </div><!-- /.col -->
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(URL::asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {

        $('#dataKurikulum').DataTable({"pageLength": 10});

      });

    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>