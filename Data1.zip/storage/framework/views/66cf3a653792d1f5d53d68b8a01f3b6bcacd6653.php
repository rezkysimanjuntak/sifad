<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Pustakawan</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
            <div class="col-md-6">
                <div class="box-body flash-message" data-uk-alert>
                    <a href="" class="uk-alert-close uk-close"></a>
                    <p><?php echo e(isset($successMessage) ? $successMessage : ''); ?></p>
                     <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php foreach($errors->all() as $error): ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="box box-primary">
                  <div class="box-header">
                    <h3 class="box-title">Tambah Pustakawan </h3>
                  </div><!-- /.box-header -->
                  <div class="box-body no-padding">
                    <form id="formPustakawanTambah" class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/pustakawan/tambahpustakawan')); ?>">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      
                      
                      <div class="form-group">
                          <label class="col-md-4 control-label">NIP </label>
                          <div class="col-md-6 <?php if($errors->has('pusNip')): ?> has-error <?php endif; ?>">
                              <input type="text" class="form-control" name="pusNip" value="<?php echo e(Request::old('pusNip')); ?>">
                              <small class="help-block"></small>
                          </div> 
                      </div>
   
                      <div class="form-group">
                          <label class="col-md-4 control-label">Nama </label>
                          <div class="col-md-6  <?php if($errors->has('pusNama')): ?> has-error <?php endif; ?>">
                              <input type="text" class="form-control" name="pusNama" value="<?php echo e(Request::old('pusNama')); ?>">
                              <small class="help-block"></small>
                         </div>
                      </div>

                      <div class="form-group">
                          <label class="col-md-4 control-label">Email </label>
                          <div class="col-md-6  <?php if($errors->has('pusEmail')): ?> has-error <?php endif; ?>">
                              <input type="text" class="form-control" name="pusEmail" value="<?php echo e(Request::old('pusEmail')); ?>">
                              <small class="help-block"></small>
                         </div>
                      </div>
   
                      <div class="form-group">
                          <label class="col-md-4 control-label">Jenis Kelamin </label>
                          <div class="col-md-6  <?php if($errors->has('pusJk')): ?> has-error <?php endif; ?>">
                              <select class="form-control" name="pusJk" value="<?php echo e(Request::old('pusJk')); ?>">
                                <option value="Laki-laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                              </select>
                              <small class="help-block"></small>
                         </div>
                      </div>

                      <div class="form-group">
                          <label class="col-md-4 control-label">TTL </label>
                          <div class="col-md-6  <?php if($errors->has('pusTtl')): ?> has-error <?php endif; ?>">
                              <input type="date" class="form-control" name="pusTtl" value="<?php echo e(Request::old('pusTtl')); ?>">
                              <small class="help-block"></small>
                         </div>
                      </div>

                      <div class="form-group">
                          <label class="col-md-4 control-label">Alamat </label>
                          <div class="col-md-6  <?php if($errors->has('pusAlamat')): ?> has-error <?php endif; ?>">
                              <input type="text" class="form-control" name="pusAlamat" value="<?php echo e(Request::old('pusAlamat')); ?>">
                              <small class="help-block"></small>
                         </div>
                      </div>

                      <div class="form-group">
                          <label class="col-md-4 control-label">Aktif Mulai </label>
                          <div class="col-md-6  <?php if($errors->has('pusAktifM')): ?> has-error <?php endif; ?>">
                              <input type="date" class="form-control" name="pusAktifM" value="<?php echo e(Request::old('pusAktifM')); ?>">
                              <small class="help-block"></small>
                         </div>
                      </div>

                      <div class="form-group">
                          <label class="col-md-4 control-label">Aktif Sampai </label>
                          <div class="col-md-6  <?php if($errors->has('pusAktifS')): ?> has-error <?php endif; ?>">
                              <input type="date" class="form-control" name="pusAktifS" value="<?php echo e(Request::old('pusAktifS')); ?>">
                              <small class="help-block"></small>
                         </div>
                      </div>

   
                      <div class="form-group">
                          <div class="col-md-6 col-md-offset-4">
                              <button type="submit" class="btn btn-primary" id="button-reg">
                                  Simpan
                              </button>

                              
                              <a href="<?php echo e(action('Pustakawan\PustakawanController@index')); ?>" title="Cancel">
                              <button type="button" class="btn btn-default" id="button-reg">
                                  Cancel
                              </button>
                              </a>  
                          </div>
                      </div>
                      </form>   
                  </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div>
          </div><!-- /.row (main row) -->
            
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>