<html>
	<head>
		<title>Cetak Nilai <?php echo e($kelaspeserta[0]['mkkurNama']); ?></title>
	</head>
	<body>
	<style type="text/css">
		table{
			width: 100%;
		}
		table, th, td {
		   /* border: 1px solid black; */
		  
		}
		th, td {
		    padding: 5px;
		    text-align: left;
		   	vertical-align: middle;
		   	border-bottom: 1px solid #ddd;
		   	font-size: 12px;
		}		
		th {
			border-top: 1px solid #ddd;
			height: 20px;
			background-color: #ddd;
			text-align : center;
		}
	</style>
					<center>
					<font size="14">REKAPITULASI NILAI<br>
					POLITEKNIK NEGERI LARASIA INDONESIA<br>
					TAHUN AKADEMIK <?php echo e(substr($semId,0,4)); ?> / <?php echo e(substr($semId,0,4)+1); ?> <?php if(substr($semId,4,1)==1 ): ?> GASAL <?php else: ?> GENAP <?php endif; ?></font>
					<br>
					<hr>
					<br>
					</center>

					           <?php if(isset($kelaspeserta)): ?>
                        
                            <table >
                                <tbody>
                                <tr>
                                  
                                  <td>KODE </td>                                  
                                  <td><span class="badge bg-white">: <?php if(!empty($kelaspeserta[0]['mkkurKode'])): ?><?php echo e($kelaspeserta[0]['mkkurKode']); ?> <?php else: ?> - <?php endif; ?> </span></td>
                                </tr>
                                <tr>
                                  <td>NAMA</td>                                  
                                  <td><span class="badge bg-light-white">: <?php if(!empty($kelaspeserta[0]['mkkurNama'])): ?><?php echo e($kelaspeserta[0]['mkkurNama']); ?> <?php else: ?> - <?php endif; ?></span></td>
                                </tr>
                                <tr>
                                  <td>SKS</td>                                 
                                  <td><span class="badge bg-yellow">: <?php if($kelaspeserta[0]['mkkurJumlahSks'] > 0): ?><?php echo e($kelaspeserta[0]['mkkurJumlahSks']); ?> <?php else: ?> 0 <?php endif; ?></span></td>                                  
                                </tr>
                                <tr>
                                  <td>Kelas</td>                                 
                                  <td><span class="badge bg-yellow">: <?php if(!empty($kelaspeserta[0]['klsNama'])): ?><?php echo e($kelaspeserta[0]['klsNama']); ?> <?php else: ?> 0 <?php endif; ?></span></td>                                  
                                </tr>
                                <tr>
                                  <td>Semester</td>                                 
                                  <td><span class="badge bg-yellow">: <?php if($kelaspeserta[0]['mkkurSemester'] > 0): ?><?php echo e($kelaspeserta[0]['mkkurSemester']); ?> <?php else: ?> 0 <?php endif; ?></span></td>                                  
                                </tr>                      
                               
                              </tbody>
                            </table>
                           
                                       
                    <?php endif; ?>
                    <br>
                    <table >
                    <thead>
                      <tr>
                        <th>No.</th>          
                        <th>NIM</th>            
                        <th>NAMA</th>                                                    
                        <th>Nilai Tugas</th>
                        <th>Nilai UTS</th>
                        <th>Nilai UAS</th>
                        <th>Nilai Akhir</th>
                        <th>Nilai Huruf</th>
                        
                      </tr>
                    </thead>
                    <tbody>
                    <?php if(! empty($kelaspeserta)): ?>
                     <?php $i=1;foreach ($kelaspeserta as $itemPeserta):  ?>
                      <tr>
                        <td align="center"><?php echo e($i); ?></td>
                        <td align="center"><?php echo e($itemPeserta->mhsNim); ?></td>
                        <td><?php echo e($itemPeserta->mhsNama); ?></td>
                        <td align="right"><?php echo e($itemPeserta->krsnaNilaiTugas); ?></td>
                        <td align="right"><?php echo e($itemPeserta->krsnaNilaiUTS); ?></td>
                        <td align="right"><?php echo e($itemPeserta->krsnaNilaiUAS); ?></td>
                        <td align="right"><?php echo e($itemPeserta->krsdtBobotNilai); ?></td>
                        <td align="center"><?php echo e($itemPeserta->krsdtKodeNilai); ?></td>
                      </tr>
                      <?php $i++; endforeach  ?>
                    <?php endif; ?> 
                    </tbody>                  
                  </table>
                  <br>
                  <table border="0" >                    
	                  <tr>
	                    <td width="70%" align="center"></td>
	                    <td align="center">Indonesia, <?php echo e(date('d-m-Y')); ?></td>	                            
	                  </tr>
	                  <tr height="60px">
	                    <td width="70%" align="center"></td>
	                    <td></td>	                            
	                  </tr>              
	                  <tr>
	                    <td width="70%" align="center"></td>
	                    <td align="center"><br><br><br><?php if(!empty($kelaspeserta[0]['dsnNama'])): ?><u><?php echo e($kelaspeserta[0]['dsnNama']); ?></u> <?php else: ?> _________________________ <?php endif; ?></td>	                            
	                  </tr>            
                  </table>
	</body>
</html>