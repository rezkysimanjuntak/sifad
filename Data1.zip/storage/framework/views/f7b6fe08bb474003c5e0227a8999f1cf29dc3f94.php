<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Nilai</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Data Nilai Siswa</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="dataNilai" class="table table-bordered table-hover">
                    <thead>
                      <tr>     
                        <th>NISN Siswa</th>
                        <th>Nama Siswa</th>
                        <th>Mata Pelajaran</th>
                        <th>Nilai Tugas</th>
                        <th>Nilai UH</th>
                        <th>Nilai UTS</th>
                        <th>Nilai UAS</th>
                        <th>Nilai Perilaku</th>
                        <th>Keterangan</th>       
                        <th>Aksi</th> 
                      </tr>
                    </thead>
                    <tbody>
                     <?php foreach ($nilai as $itemNilai):  ?>
                      <tr>
                        <td><?php echo e($itemNilai->sisNisn); ?></td>
                        <td><?php echo e($itemNilai->sisNama); ?></td>
                        <td><?php echo e($itemNilai->mapelNama); ?></td>
                        <td><?php echo e($itemNilai->nilaiTugas); ?></td>
                        <td><?php echo e($itemNilai->nilaiUh); ?></td>
                        <td><?php echo e($itemNilai->nilaiUts); ?></td>
                        <td><?php echo e($itemNilai->nilaiUas); ?></td>
                        <td><?php echo e($itemNilai->nilaiPerilaku); ?></td>
                        <td><?php echo e($itemNilai->nilaiKeterangan); ?></td>
                        <?php if(Auth::user()->level==1): ?>
                        <?php else: ?>
                            <td><a href="<?php echo e(URL::to('datanilai/'.$itemNilai->nilaiId.'/edit')); ?>">
                                  <span class="label label-warning"><i class="fa fa-list"> Edit </i></span>
                                </a>
                            </td>
                        <?php endif; ?>
                      </tr>
                      <?php endforeach  ?> 

                      <?php foreach ($nilaisd as $itemNilaiS):  ?>
                      <tr>
                        <td><?php echo e($itemNilaiS->sisNisn); ?></td>
                        <td><?php echo e($itemNilaiS->sisNama); ?></td>
                        <td><?php echo e($itemNilaiS->mapelNama); ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <?php if(Auth::user()->level==1): ?>
                        <?php else: ?>
                            <td><a href="<?php echo e(URL::to('datanilai/'.$itemNilai->guruId.'/'.$itemNilai->sisNisn.'/'.$itemNilai->mapelKode.'/tambah')); ?>">
                                  <span class="label label-success"><i class="fa fa-list"> Tambah </i></span>
                                </a>
                            </td>
                        <?php endif; ?>
                      </tr>
                      <?php endforeach  ?> 
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>NISN Siswa</th>
                        <th>Nama Siswa</th>
                        <th>Mata Pelajaran</th>
                        <th>Nilai Tugas</th>
                        <th>Nilai UH</th>
                        <th>Nilai UTS</th>
                        <th>Nilai UAS</th>
                        <th>Nilai Perilaku</th>
                        <th>Keterangan</th>                         
                        <th>Aksi</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

            </div><!-- /.col -->
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(URL::asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {

        $('#dataNilai').DataTable({"pageLength": 10});

      });

      
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>