<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Dosen</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard Dosen</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Semester Aktif Dosen </h3>
                </div><!-- /.box-header -->
                <div class="box-body flash-message">
                  <?php if(session('success')): ?> 
                  <div class="alert alert-info">
                    <strong><?php echo e(session('success')); ?></strong>
                  </div>
                  <?php elseif(session('error')): ?> 
                  <div class="alert alert-error">
                    <strong><?php echo e(session('error')); ?></strong>
                  </div>
                  <?php endif; ?>      
                </div>
                <div class="box-header">                  
                      <form id="formKelasProdi" class="form-horizontal" role="form" method="POST" action="<?php echo e(route('dosenkelassemester')); ?>">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      <div class="form-group">
                          <label class="col-md-4 control-label">Tahun Akademik</label>
                          <div class="col-md-4 ">
                              <select class="form-control" name="semId">
                                  <?php foreach($listSmtDsn as $itemSmtDsn): ?>
                                  <option value="<?php echo e($itemSmtDsn->sempSemId); ?>" <?php if($itemSmtDsn->sempSemId ==$SmtDsn_terpilih): ?> ? ' selected="selected"' : '' <?php endif; ?> > <?php echo e($itemSmtDsn->semKeterangan); ?></option>
                                  <?php endforeach; ?>
                              </select>
                              
                              <small class="help-block"></small>
                          </div>
                          <div class="form-group">
                              <div class="col-md-2 ">
                                  <button type="submit" class="btn btn-flat btn-social btn-dropbox" id="button-reg">
                                    <i class="fa  fa-hand-o-left"></i>  Pilih  
                                  </button>
                              </div>
                          </div>
                      </div>
                      </form>
                </div><!-- /.box-header -->
                <div class="box-header">                  
                    <?php if(isset($IPK)): ?>
                        <?php foreach($IPK as $itemIPK): ?>
                            <table class="table table-bordered ">
                                <tbody><tr>                                  
                                  <th colspan="2" align="center">Nilai IPK</th>                                  
                                  <th colspan="2" align="center">Nilai IPS</th>
                                </tr>
                                <tr>
                                  
                                  <td>IPK</td>                                  
                                  <td><span class="badge bg-red"> <?php if($itemIPK->IPK > 0): ?><?php echo e($itemIPK->IPK); ?> <?php else: ?> 0 <?php endif; ?> </span></td>

                                  <td>IPS</td>                                  
                                  <td><span class="badge bg-light-blue"><?php if($IPS->IPS > 0): ?><?php echo e($IPS->IPS); ?> <?php else: ?> 0 <?php endif; ?></span></td>
                                </tr>
                                <tr>
                                  <td>JML SKS IPK</td>                                 
                                  <td><span class="badge bg-yellow"><?php if($itemIPK->jmlSks > 0): ?><?php echo e($itemIPK->jmlSks); ?> <?php else: ?> 0 <?php endif; ?></span></td>

                                  <td>JML SKS IPS</td>                                 
                                  <td><span class="badge bg-green"><?php if($IPS->jmlSks > 0): ?><?php echo e($IPS->jmlSks); ?> <?php else: ?> 0 <?php endif; ?> </span></td>
                                </tr>
                               
                              </tbody>
                            </table>
                           
                        <?php endforeach; ?>                        
                    <?php endif; ?>                   
        
                </div><!-- /.box-header -->
                
                <div class="box-body" >
                  <table id="dataKurikulum" class="table table-bordered table-hover">
                    <thead>
                      <tr>    
                        <th>No</th>                    
                        <th>Kode </th>
                        <th width="65%">Matakuliah</th>
                        <th>SKS </th>
                        <th>Semester </th>
                        <th>Kelas</th>   
                        <th>Aksi</th>                      
                      </tr>
                    </thead>
                    <tbody>
                    <?php if(! empty($dataAmpuSmt)): ?>
                     <?php $i=1;foreach ($dataAmpuSmt as $itemDataAmpu):  ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($itemDataAmpu->mkkurKode); ?></td>
                        <td><?php echo e($itemDataAmpu->mkkurNama); ?></td>
                        <td><?php echo e($itemDataAmpu->mkkurJumlahSks); ?></td>
                        <td><?php echo e($itemDataAmpu->mkkurSemester); ?></td>
                        <td><?php echo e($itemDataAmpu->klsNama); ?></td>
                        <td>                           
                            <a class="btn btn-info btn-flat btn-sm" href="<?php echo e(route('pesertakelassemester',[$itemDataAmpu->klsId])); ?>" title="Peserta Matakuliah"><i class="fa fa-list"> </i> Peserta
                            </a> 
                            
                        </td>
                       
                      </tr>
                      <?php $i++; endforeach  ?>
                    <?php endif; ?> 
                    </tbody>
                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

            </div><!-- /.col -->
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(URL::asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {

        $('#dataKurikulum').DataTable({"pageLength": 10});

      });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>