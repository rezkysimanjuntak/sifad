<?php $__env->startSection('content'); ?>

    <center>
      <div id="loginWrapper">
         <div id="loginBox">    
            <div id="loginBox-head">
            <div id="loginBoxhead_img"><img src="<?php echo e(URL::asset('auth/images/logo.png')); ?>" alt="" width="45" height="45" /></div>
                <h1>LaraSIA</h1>
            </div>
            <div id="loginBox-title">
               <h2>Portal Akademik</h2>
               <img src="<?php echo e(URL::asset('auth/images/loginBox-title-img-mid.jpeg')); ?>" alt="">
            </div>
             <div id="loginBox-body">

               <form id="form-login" name="form-login"  action="<?php echo e(url('/login')); ?>" method="post" autocomplete="off">
               <?php echo csrf_field(); ?>

               
                  <label for="aid_username">Username</label>
                  <input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>" onBlur="clearPasswordField();" />
                  
                  <?php if($errors->has('username')): ?>
                      <br><span class="help-block">
                          <strong><?php echo e($errors->first('username')); ?></strong>
                      </span>
                  <?php endif; ?>

                  <br />
                  <label for="aid_password">Password</label>
                  <input type="password" id="password" name="password" value="" />
                  <?php if($errors->has('password')): ?>
                      <br><span class="help-block">
                          <strong><?php echo e($errors->first('password')); ?></strong>
                      </span>
                  <?php endif; ?> 
                  <br />
                  <label> </label>
                    <input class="button" type="submit" value="Login" />

               </form>
            </div>
            <div id="loginBox-foot"></div>
         </div>
        </div>  
   </center>

<!-- <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                        <?php echo csrf_field(); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input type="email" class="form-control" name="email"  >

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input type="password" class="form-control" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember"> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-sign-in"></i>Login
                                </button>

                                <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>