<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Kelas</li>
            <li class="active">Detail Kelas</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          
          <div class="row">
            <div class="col-md-12">
              <div class="box box-danger">
                <div class="box-header with-border">
                  <h3 class="box-title">Data Kelas</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                 <?php foreach ($kelas as $itemKelas);  ?>
                <div class="box-body">
                  <div class="row">
                    <div class="col-md-3">
                      <p align="center">
                        <img src="<?php echo e(URL::asset('admin/dist/img/user-160-nobody.jpg')); ?>" alt="User Image">
                        <a class="users-list-name" href="#"><?php echo e($itemKelas->kelasNama); ?></a>
                        <span class="users-list-date">Kelas Tetap</span>
                      </p>
                    </div><!-- /.col -->
                    <div class="col-md-8">
                     <table id="dataKurikulum" class="table table-bordered table-hover">                    
                      <tbody>
                      
                        <tr>
                          <td>Kode Kelas</td>  
                          <td><?php echo e($itemKelas->kelasKode); ?></td>
                        </tr>
                        <tr>
                          <td>Nama Kelas</td> 
                          <td><?php echo e($itemKelas->kelasNama); ?></td>
                        </tr>
                        <tr>
                          <td>Daftar Siswa</td> 
                          <td><a href="<?php echo e(URL::to('kelas/'.$itemKelas->kelasKode.'/siswa')); ?>">
                              <span class="label label-info"><i class="fa fa-list"> Detail </i></span>
                              </a>
                        </td>
                        </tr>
                        
                      </tbody>
                      
                    </table>
                    </div><!-- /.col -->
                  </div><!-- /.row -->
                </div><!-- /.box-body -->
                 
              </div>
            </div>
                       
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

  

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>