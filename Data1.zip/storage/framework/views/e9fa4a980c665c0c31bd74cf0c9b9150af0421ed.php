<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Detail Mangkir Pegawai</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          <!-- Awal Graph -->
          <div class="row">
            <div class="col-xs-12">
              <!-- Custom Pegawai-->
               <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-bar-chart"></i>
                  <h3 class="box-title">Pelanggaran Disiplin Pegawai</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button class="btn bg-teal btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div><!-- /. tools -->
                </div>
                <div class="box-body">
                    <div id="pegawai" style="position: relative; height: 500px;  width: 100%;"></div>
                </div>                
              </div><!-- /.pegawai -->

            </div><!-- /.col -->
          </div><!-- /.row akhir graph-->

          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Detail mangkir pegawai dalam per Bulan pada tiap Tahun</h3><br><br>
                  <h2 class="box-title">Pegawai :<b><?php echo e($dataMangkir[0]['pegKode']); ?> - <?php echo e($dataMangkir[0]['pegNama']); ?></b></h2><br>
                  <h2 class="box-title">Kelompok :<b><?php echo e($dataMangkir[0]['kelNama']); ?> </b></h2>
                </div><!-- /.box-header -->
                <div class="box-body" style="overflow:auto; position:relative;width:100%;height:400px;float:center;">
                  
                  <table id="datapegawai" class="table table-bordered table-hover" style="width:100%">
                    <thead>
                      <tr bgcolor="#4cb0fd"  align="center" style="font-weight: bold;">
                        <td rowspan="2" valign="center">Tahun</td>
                        <td rowspan="2" valign="center">Bulan</td> 
                        <td colspan="31" align="center">Tanggal</td>  
                        <td rowspan="2" align="center">Mangkir<br>(menit)</td>
                        <td rowspan="2" align="center">Mangkir<br>(kali)</td>
                      </tr>
                      <tr>

                        <?php for($i=1;$i<=31;$i++):  ?>
                        <?php echo "<td bgcolor='#4cb0fd' style='font-weight: bold;'>$i</td>"; ?>
                        <?php endfor  ?>


                      </tr>
                    </thead>
                    <tbody>
                     <?php foreach ($dataMangkir as $itemMangkir):  ?>
                      <tr>
                        <td><?php echo e($itemMangkir->mkrTahun); ?></td>
                        <td><?php echo e($itemMangkir->mkrBln); ?></td>
                        <?php for($i=1;$i<=31;$i++){  
                            $tgl='mkrTgl'.$i;
                            //echo $tgl;  
                            if($itemMangkir->$tgl > 0){
                              echo "<td bgcolor='yellow'>".$itemMangkir->$tgl."</td>";
                            }else{
                              echo "<td>".$itemMangkir->$tgl."</td>";
                            }
                         } ?> 
                        <td align="center"><?php echo e($itemMangkir->mkrJmlMnt); ?></td>
                        <td bgcolor="aqua" align="center"><?php echo e($itemMangkir->Jumlah); ?></td>

                      </tr>
                      <?php endforeach  ?> 
                    </tbody>
                   
                  </table>
                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->

            </div><!-- /.col -->
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script src="<?php echo e(URL::asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script>
  $(function () {

    //var kategori_mangkir = <?php //echo $kategori_mangkir; ?>;
    var data_mangkir = <?php echo $mangkir; ?>;

        //$("#example1").DataTable();
        /*       $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });*/
    $('#datapegawai').DataTable({          
          "paging": false,
          "lengthChange": false,
          "searching": false,
          "ordering": false,
          "info": false,
          "autoWidth": false});

            //Jam Kompensasi - Keterlambatan Alpha Kuliah
    $('#pegawai').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            //type: 'column'
            //type:'areaspline'
            type:'line'
        },
        title: {
            text: 'Pelanggaran Individu per Bulan ',
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            //categories: kategori_mangkir
            categories: ["Januari", "Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"]
            ,
            /*plotBands: [{ // visualize the weekend
                from: 4.5,
                to: 6.5,
                color: 'rgba(68, 170, 213, .2)'
            }]*/

        },
        yAxis: {
            title: {
                text: 'Jumlah'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ' kali'
        },
        legend: {
            layout: 'vertical',
            //layout: 'horizontal',
            //align: 'right',
            verticalAlign: 'bottom',
            borderWidth: 0
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: true
            },
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: data_mangkir
    });

      });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>